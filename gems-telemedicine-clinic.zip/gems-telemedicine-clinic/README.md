# GEMS Telemedicine Clinic – Student Health Portal

A single-page web portal for a college telemedicine clinic: appointments & OPD tokens, doctor availability,
digital prescriptions and bills (PDF), medicine list, health camps, and an SOS emergency alert.
Built with plain HTML, Tailwind CSS (CDN), JavaScript, jsPDF, QRCode.js and optional Firebase Realtime Database.

## Run locally
Open `index.html` in a browser (no build step).

## Deploy on GitHub Pages
1. Push this folder to a GitHub repository.
2. Repository **Settings → Pages**.
3. Source: **Deploy from a branch** → Branch: `main` → Folder: `/ (root)` → Save.
4. Your site goes live at `https://<your-username>.github.io/<repo-name>/`.

## Project structure
```
index.html      main app (all pages/sections are inside this file)
assets/         images (logo: gems-telemedicine-logo.jpeg)
.nojekyll       tells GitHub Pages to serve files as-is
README.md
```

## Optional: cross-device doctor presence (Firebase)
In `index.html`, find `GEMS_FIREBASE_CONFIG` and replace the `YOUR_...` placeholders with your Firebase project values.
Until then, the app runs fine using browser localStorage only.

## Notes
- Data is stored in the browser (`localStorage`), so it is per-device and not a real backend.
- This is a student project / demo. Do not store real patient data in it.
