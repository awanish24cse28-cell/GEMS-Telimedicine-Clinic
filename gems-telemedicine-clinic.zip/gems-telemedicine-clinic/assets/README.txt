Put your logo here, named exactly:  gems-telemedicine-logo.jpeg
(index.html loads assets/gems-telemedicine-logo.jpeg; if it is missing, a fallback icon is shown.)
